Completed Level 5, Feel like i desereve like a 100% maybe a 110% cause I added validation
for my add buttons so my program doesnt crash if the user puts  in incorrect information.

Added tons of methods to Client class some need some not need explained in comments, everything works 
perfectly fine however.